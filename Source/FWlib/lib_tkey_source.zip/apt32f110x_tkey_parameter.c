
/*
  ******************************************************************************
  * @file    apt32f110x_tkey_parameter.c
  * @author  APT AE Team
  * @version V1.00
  * @date    2022/08/08
  ******************************************************************************
  *THIS SOFTWARE WHICH IS FOR ILLUSTRATIVE PURPOSES ONLY WHICH PROVIDES 
  *CUSTOMER WITH CODING INFORMATION REGARDING THEIR PRODUCTS.
  *APT CHIP SHALL NOT BE HELD RESPONSIBILITY ADN LIABILITY FOR ANY DIRECT, 
  *INDIRECT DAMAGES WITH RESPECT TO ANY CLAIMS ARISING FROM THE CONTENT OF 
  *SUCH SOFTWARE AND/OR THE USE MADE BY CUSTOMERS OF THE CODING INFORMATION 
  *CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.AND APT CHIP RESERVES 
  *THE RIGHT TO MAKE CHANGES IN THE SOFTWARE WITHOUT NOTIFICATION
  ******************************************************************************
  */

#include "apt32f110x_tkey.h"



void tk_parameter_init(void)
{
/****************************************************
//TK basic parameters
*****************************************************/
	TK_IO_ENABLE=TCH_EN(4)|TCH_EN(5)|TCH_EN(8)|TCH_EN(9)|
				 TCH_EN(29)|TCH_EN(26)|TCH_EN(22)|TCH_EN(23);
	TK_Global_Sens=3;								//TK Global Tkey Sensitivity,0=invalid;
	TK_Global_Trigger=50;							//TK Global Tkey Trigger,0=invalid;
	TK_Global_Icon=4;								//TK Global Tkey Icon,0=invalid;
	Press_debounce=5;								//Press debounce 1~10
	Release_debounce=5;								//Release debounce 1~10
	Key_mode=2;										//Key mode 0=first singlekey,1=multi key,2=strongest single-key
	MultiTimes_Filter=0;							//MultiTimes Filter,>4 ENABLE <4 DISABLE
	Valid_Key_Num=2;								//Valid Key number when touched
	Base_Speed=5;									//baseline update speed
	TK_Rebuild_Time=10;								//longpress rebuild time = TK_Rebuild_Time*1s  0=disable
	TK_BaseCnt=59999;								//10ms  TK_BaseCnt=10ms*48M/8-1,this register need to modify when mcu's Freq changed
/****************************************************
//TK parameter fine-tuning
*****************************************************/
	TK_Fine_Turn=DISABLE;							//Tkey sensitivity fine tuning ENABLE/DISABLE
	TK_CHx_Sens[0]=4;								//TCHx manual Sensitivity
	TK_CHx_Sens[1]=4;								//TCHx manual Sensitivity
/****************************************************
//TK special parameter define
*****************************************************/
	TK_PSEL_MODE=TK_PWRSRC_AVDD;					//tk power sel:TK_PWRSRC_FVR/TK_PWRSRC_AVDD   when select TK_PSEL_FVR PA0.0(TCH24) need a 104 cap
	TK_EC_LEVEL=TK_ECLVL_1V;						//C0 voltage sel:TK_ECLVL_1V/TK_ECLVL_2V/TK_ECLVL_3V/TK_ECLVL_3V6
	TK_FVR_LEVEL=TK_FVR_NONE;						//FVR level:TK_FVR_2048V/TK_FVR_4096V/TK_FVR_NONE
}





